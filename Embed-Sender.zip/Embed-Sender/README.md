# Discord Message Sender Template

A complete web-based Discord message sender with OAuth2 authentication, full embed editor, AI-powered text improvement, and multi-server management. Send custom-branded messages with rich embeds, images, and auto-generated webhooks.

## Features

### 🔐 Authentication
- Discord OAuth2 login integration
- Secure session management with httpOnly cookies
- Auto-generated session secrets

### 🤖 Discord Integration (Two Setup Methods)
**Auto-Setup with Bot** (Recommended):
- Automatic server info fetching via Discord API
- Auto-creates webhooks for all text channels
- Reuses existing webhooks by server name (prevents duplicates)
- Supports multiple Discord servers with easy switching

**Manual Webhook Entry** (No bot required):
- Simply paste your webhook URL
- No bot invitation needed
- Perfect for quick setup or single-channel use
- Just create a webhook in Discord and paste the URL

### 🎨 Full Discord Embed Editor
- **Author Section**: Name and icon (clickable image upload)
- **Title**: Bold, clickable headline
- **Description**: Rich text content
- **Custom Fields**: Name/value pairs (inline support)
- **Embed Image**: Large image display (clickable upload)
- **Footer**: Text and icon (clickable upload)
- **Color Picker**: 6 preset colors + custom hex input
- Live preview that matches Discord's appearance

### 🖼️ Image Upload System
- Clickable image boxes for easy upload
- Base64 conversion for direct embedding
- Visual preview before sending
- Support for author icon, embed image, and footer icon

### ✨ AI-Powered Text Improvement
- One-click text enhancement with OpenAI GPT-4o-mini
- Fixes grammar, spelling, and improves professionalism
- Works on all text fields simultaneously
- Powered by Replit AI Integrations (no API key needed)

### 💾 Multi-Server Management
- Save multiple Discord servers in localStorage
- Quick server switching with visual interface
- Shows server logos and names
- Add/remove servers anytime

### 🔧 Custom Branding
- Override server name and logo per message
- Messages appear with custom identity in Discord

## Prerequisites

### For Auto-Setup with Bot (Recommended for multiple channels)

1. **Discord Application & Bot**
   - Create a Discord application at [Discord Developer Portal](https://discord.com/developers/applications)
   - Create a bot user and get the bot token
   - Note your Client ID and Client Secret for OAuth2

2. **Bot Permissions**
   - Enable "Manage Webhooks" permission
   - Use this invite URL format:
     ```
     https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=536870912&scope=bot
     ```

3. **OAuth2 Setup**
   - Add redirect URL: `https://your-repl-url.replit.app/callback`
   - For local development: `http://localhost:5000/callback`

### For Manual Webhook Entry (Quick setup, no bot needed)

1. **Discord OAuth2 Only**
   - Create a Discord application at [Discord Developer Portal](https://discord.com/developers/applications)
   - Note your Client ID and Client Secret for OAuth2
   - Add redirect URL as above
   - **No bot needed!**

2. **Create a Webhook in Discord**
   - Go to your Discord channel
   - Channel Settings → Integrations → Webhooks
   - Create a new webhook and copy the URL

## Environment Setup

This template requires three Discord secrets:

1. **DISCORD_CLIENT_ID** - Your Discord application's Client ID
2. **DISCORD_CLIENT_SECRET** - Your Discord application's Client Secret
3. **DISCORD_TOKEN** - Your Discord bot token

### Setting Secrets in Replit

**Required for all setups:**
1. Click the "Secrets" tab (lock icon) in your Repl
2. Add these secrets:
   - Key: `DISCORD_CLIENT_ID`, Value: Your Client ID
   - Key: `DISCORD_CLIENT_SECRET`, Value: Your Client Secret

**Required only for Auto-Setup with Bot:**
   - Key: `DISCORD_TOKEN`, Value: Your Bot Token

**Note:** If using Manual Webhook Entry only, you can skip the DISCORD_TOKEN secret.

The app will automatically use Replit AI Integrations for the AI Improve feature (no OpenAI key needed).

## Installation

1. **Fork or Clone this Repl**

2. **Install Dependencies** (automatic in Replit)
   ```bash
   npm install
   ```

3. **Configure Discord Secrets** (see Environment Setup above)

4. **Run the Application**
   ```bash
   npm start
   ```
   Or click the "Run" button in Replit

5. **Access the App**
   - Local: `http://localhost:5000`
   - Replit: Your Repl's webview URL

## How to Use

### First Time Setup

1. **Login with Discord**
   - Click "Login with Discord" on the homepage
   - Authorize the application

2. **Choose Your Setup Method**

   **Option A: Auto-Setup with Bot** (For multiple channels)
   - Click "🤖 Auto-Setup with Bot" button
   - Add the bot to your server using the invite link
   - Enter your Discord Server ID
   - Click "Generate Webhooks"
   - The app will:
     - Fetch server name and logo
     - Check for existing webhooks in each channel
     - Create new webhooks only where needed
     - Reuse existing webhooks by server name
   
   **Option B: Manual Webhook Entry** (Quick & simple - No bot needed!)
   - Click "✏️ Manual Webhook Entry" button
   - Paste your server invite link (the app will fetch server name and logo automatically)
   - Paste your webhook URL from Discord (the app will fetch channel name automatically)
   - Click "Save Webhook"
   - Done! Only 2 fields required, everything else is automatic.

3. **Select a Channel**
   - Choose which channel to send messages to (auto-setup only)
   - For manual setup, you'll use the channel you configured

### Sending Messages

1. **Fill in Embed Fields** (all optional):
   - Author name and icon
   - Title
   - Description
   - Custom field name/value
   - Embed image
   - Footer text and icon
   - Color (preset or custom hex)

2. **Upload Images** (optional):
   - Click any image box to upload
   - Preview appears immediately
   - Images are base64-encoded

3. **Enhance with AI** (optional):
   - Fill in some text
   - Click "✨ AI Improve"
   - AI will enhance grammar and professionalism

4. **Send**:
   - Click "Send Message"
   - Message appears instantly in Discord

### Managing Multiple Servers

- Click "Manage Servers" to see all saved servers
- Click a server to switch to it
- Remove servers you no longer need
- Add new servers anytime

## Technical Details

### Stack
- **Backend**: Node.js + Express
- **Frontend**: Vanilla JavaScript (no frameworks)
- **Database**: None (uses localStorage for client-side persistence)
- **AI**: OpenAI GPT-4o-mini via Replit AI Integrations
- **Authentication**: Discord OAuth2

### API Endpoints

- `GET /` - Main application
- `GET /auth` - Discord OAuth2 login
- `GET /callback` - OAuth2 callback handler
- `GET /client-id` - Get Discord client ID
- `POST /setup-webhooks` - Auto-setup webhooks for a server
- `POST /send-message` - Send Discord message via webhook
- `POST /ai-improve` - AI text enhancement
- `GET /logout` - Destroy session

### Security Features

- Session secret auto-generated with crypto.randomBytes()
- httpOnly cookies prevent XSS attacks
- sameSite='lax' prevents CSRF
- Authentication required for all API endpoints
- Secrets never exposed to client

### Webhook Management

The app intelligently manages webhooks:
1. Checks for existing webhooks in each channel
2. Looks for webhooks created by the bot with server name
3. Reuses existing webhooks (prevents duplicates)
4. Only creates new webhooks when needed
5. Works across multiple users sharing the same server

**Important**: The bot must remain in the server for webhooks to continue working.

## Customization

### Change Color Presets

Edit the color buttons in `public/index.html`:
```javascript
const colorOptions = document.querySelectorAll('.color-option');
```

### Modify AI Prompt

Edit the AI improvement prompt in `server.js`:
```javascript
const prompt = `You are a Discord message editor...`;
```

### Add More Embed Fields

Discord supports multiple custom fields. Extend the form in `public/index.html` to add more field inputs.

## Troubleshooting

**"Failed to fetch server info"**
- Ensure the bot is in the server
- Check that DISCORD_TOKEN is set correctly
- Verify the Server ID is correct

**"Failed to send message"**
- Check that webhooks are set up
- Ensure the channel still exists
- Verify the bot hasn't been removed

**AI Improve not working**
- Replit AI Integrations must be available
- Check server logs for errors
- Ensure you have Replit credits

**Login redirect not working**
- Verify DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET are set
- Check OAuth2 redirect URL matches your Repl URL
- Ensure `/callback` is added in Discord Developer Portal

## Publishing

When ready to make your app public:

1. Click the "Deploy" button in Replit (ship icon)
2. Follow the prompts to publish
3. Update your Discord OAuth2 redirect URL to match the published URL
4. Share your app URL with others!

## Credits

Built with:
- [Express.js](https://expressjs.com/) - Web framework
- [Discord.js](https://discord.js.org/) - Discord library
- [OpenAI](https://openai.com/) - AI text improvement
- [Replit AI Integrations](https://replit.com/) - Seamless AI integration

## License

MIT License - Feel free to use this template for your own projects!

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review Discord Developer Portal settings
3. Check server logs for error messages
4. Ensure all environment secrets are set correctly

---

**Note**: This is a template designed for Replit. It uses Replit AI Integrations for AI features and is optimized for the Replit environment.
